use clinica;

INSERT INTO paciente(name,address,phone) values ('Kevin Park','76 Princess Dr. Lakeland, FL 33801','294720472');
INSERT INTO paciente(name,address,phone) values ('Joe Felix','33 Holly Ave. Williamstown, NJ 08094','494720472');
INSERT INTO paciente(name,address,phone) values ('Mary Phonenix','4 Arch Street Millville, NJ 08332','894720472');
INSERT INTO paciente(name,address,phone) values ('Josh Koe','693 Victoria St. Macungie, PA 18062','6794720472');
INSERT INTO paciente(name,address,phone) values ('Mariah Steven','74 Somerset St. Sioux Falls, SD 57103','294720472');
INSERT INTO paciente(name,address,phone) values ('Mark Plum','8652 Delaware Road Inman, SC 29349','194720472');
INSERT INTO paciente(name,address,phone) values ('Larry Worth','8233 Roosevelt St. Burnsville, MN 55337','538329298');
INSERT INTO paciente(name,address,phone) values ('Sarah Lee','540 Sussex Rd. Ozone Park, NY 11417','9058747322');
INSERT INTO paciente(name,address,phone) values ('Martin McLee','48 Blue Spring Road Milwaukee, WI 53204','9298748490');